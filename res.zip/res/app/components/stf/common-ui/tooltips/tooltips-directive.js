module.exports = function tooltipsDirective() {
  return {
    restrict: 'A',
    link: function() {
    }
  }
}
