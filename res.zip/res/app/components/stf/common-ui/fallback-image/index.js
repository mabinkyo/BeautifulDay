module.exports = angular.module('stf.fallback-image', [

])
  .directive('fallbackImage', require('./fallback-image-directive'))
