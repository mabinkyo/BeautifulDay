module.exports = angular.module('stf.focus-element', [

])
  .directive('focusElement', require('./focus-element-directive'))
