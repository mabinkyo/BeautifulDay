module.exports = function StandaloneCtrl() {

}
