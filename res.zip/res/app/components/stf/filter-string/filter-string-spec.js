describe('FilterStringService', function() {

  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	//expect(FilterStringService.doSomething()).toEqual('something')

  }))

})
