describe('NativeUrlService', function() {

  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	//expect(NativeUrlService.doSomething()).toEqual('something')

  }))

})
