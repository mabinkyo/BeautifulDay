module.exports = function NotificationsServiceFactory() {
  var NotificationsService = {}


  return NotificationsService
}
