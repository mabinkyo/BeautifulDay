describe('LightboxImageService', function() {

  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	//expect(XLightboxImageService.doSomething()).toEqual('something');

  }))

})
