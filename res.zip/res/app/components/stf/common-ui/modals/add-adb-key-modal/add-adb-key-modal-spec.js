describe('FatalMessageService', function() {

  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	//expect(FatalMessageService.doSomething()).toEqual('something');

  }))

})
