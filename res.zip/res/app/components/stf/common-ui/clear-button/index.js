module.exports = angular.module('stf.clear-button', [])
  .directive('clearButton', require('./clear-button-directive'))
