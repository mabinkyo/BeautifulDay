require('./timelines.css')

module.exports = angular.module('stf.timelines', [

])
  .directive('timelines', require('./timelines-directive'))
