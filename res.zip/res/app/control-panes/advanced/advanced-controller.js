module.exports = function AdvancedCtrl() {

}
