var oboe = require('oboe')

module.exports = function DeviceGroupsService($http,
    AppState) {
    return {
        

    }

}