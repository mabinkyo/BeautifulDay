module.exports = function ResourcesCtrl() {

}
