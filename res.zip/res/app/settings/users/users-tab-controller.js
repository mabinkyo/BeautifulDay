var oboe = require('oboe')
module.exports = function usersTabController($scope, AppState) {
    $scope.activeTabs = {
        users: true,
        group: false
    }
}