module.exports = function GeneralCtrl() {

}
