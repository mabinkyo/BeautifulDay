module.exports = angular.module('stf.text-focus-select', [

])
  .directive('textFocusSelect', require('./text-focus-select-directive'))
