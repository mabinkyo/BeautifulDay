describe('install', function() {

  beforeEach(angular.mock.module(require('./').name))

	it('should ...', inject(function() {

    //var filter = $filter('installError')

		//expect(filter('input')).toEqual('output')

	}))

})
