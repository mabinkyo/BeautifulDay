module.exports = angular.module('stf.text-history', [

])
  .directive('textHistory', require('./text-history-directive'))
