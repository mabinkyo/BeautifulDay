# stf-tooltips

Based on Angular Bootstrap.

Usage:

```html
help-title='{{"Run Command"|translate}}'
help-key='Enter'
```

Maps to:

```html
tooltip-html-unsafe='{{"Run Command<br /><br /><code>Enter</code>"|translate}}'
```