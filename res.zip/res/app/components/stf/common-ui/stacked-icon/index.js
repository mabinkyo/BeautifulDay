module.exports = angular.module('stf.stacked-icon', [])
  .directive('stackedIcon', require('./stacked-icon-directive'))
