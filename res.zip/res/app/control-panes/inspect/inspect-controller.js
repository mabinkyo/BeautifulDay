module.exports = function InspectCtrl() {

}
