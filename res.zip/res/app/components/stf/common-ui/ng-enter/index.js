module.exports = angular.module('stf.ng-enter', [

])
  .directive('ngEnter', require('./ng-enter-directive'))
