module.exports = angular.module('stf.timeline-message', [

])
  .directive('timelineMessage', require('./timeline-message-directive'))
