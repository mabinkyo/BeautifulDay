describe('ScopedHotkeysService', function() {

  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	//expect(ScopedHotkeysService.doSomething()).toEqual('something')

  }))

})
