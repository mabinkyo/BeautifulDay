module.exports = angular.module('stf.admin-mode', [

])
  .directive('adminMode', require('./admin-mode-directive'))
