require('./modals.css')

module.exports = angular.module('stf.modals.common', [
  require('ui-bootstrap').name
])
