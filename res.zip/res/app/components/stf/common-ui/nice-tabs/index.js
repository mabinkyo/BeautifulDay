module.exports = angular.module('stf.nice-tabs', [

])
  .directive('niceTab', require('./nice-tab-directive'))
  .directive('niceTabs', require('./nice-tabs-directive'))
