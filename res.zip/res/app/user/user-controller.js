module.exports =
  function UserCtrl() {


  }
