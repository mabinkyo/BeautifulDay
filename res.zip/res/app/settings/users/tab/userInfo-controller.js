var oboe = require('oboe')
/*
module.exports = function UserInfoController($scope,AppState) {

    $scope.synenable = true
    $scope.vm = {
        value: 0,
        style: 'progress-bar-info',
        showLabel: true,
        striped: true
    }
    

}
*/