module.exports = angular.module('stf.page-visibility', [

])
  .factory('PageVisibilityService', require('./page-visibility-service'))
