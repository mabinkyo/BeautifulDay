describe('SocketDisconnectedService', function() {

  beforeEach(angular.mock.module(require('./index').name))

  it('should ...', inject(function() {

	//expect(SocketDisconnectedService.doSomething()).toEqual('something')

  }))

})
