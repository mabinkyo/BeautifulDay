module.exports = angular.module('stf.blur-element', [

])
  .directive('blurElement', require('./blur-element-directive'))
