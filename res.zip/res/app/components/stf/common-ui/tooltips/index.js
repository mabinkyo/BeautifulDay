module.exports = angular.module('stf.tooltips', [

])
  .directive('tooltips', require('./tooltips-directive'))
